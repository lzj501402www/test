# video_download


### Prerequisites

The following dependencies are necessary:

* **[Python](https://www.python.org/downloads/)**  3 or above
* **[aria2](https://aria2.github.io/)** 

```
# pip install pycryptodome
```

## Getting Started

### Download a video with m3u8


#aria2c.exe  --conf-path=aria2.conf


#mitmdump -s proxy.py --flow-detail 0



